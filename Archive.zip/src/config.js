'use strict';

const path = require('path');
const config = require('everyconfig')(path.join(__dirname, '..', 'config'));


module.exports = config
    

